public class homework_2 {

	public static void main(String[] args) {
		Register account = new Register(); //Register class ����
		
		account.getInformations(); //getInformations �޼ҵ� ȣ��
		account.isEqual(); //isEqual �޼ҵ� ȣ��
	}
}
